import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import { Ellipse1Icon } from './Ellipse1Icon';
import { Ellipse1Icon2 } from './Ellipse1Icon2';
import { Ellipse1Icon3 } from './Ellipse1Icon3';
import { Ellipse2Icon } from './Ellipse2Icon';
import { Ellipse2Icon2 } from './Ellipse2Icon2';
import { Ellipse2Icon3 } from './Ellipse2Icon3';
import { Ellipse3Icon } from './Ellipse3Icon';
import { Ellipse3Icon2 } from './Ellipse3Icon2';
import { Ellipse3Icon3 } from './Ellipse3Icon3';
import { Ellipse4Icon } from './Ellipse4Icon';
import { Ellipse4Icon2 } from './Ellipse4Icon2';
import { Ellipse4Icon3 } from './Ellipse4Icon3';
import { Ellipse4Icon4 } from './Ellipse4Icon4';
import { Ellipse4Icon5 } from './Ellipse4Icon5';
import { Ellipse4Icon6 } from './Ellipse4Icon6';
import { Ellipse5Icon } from './Ellipse5Icon';
import { Ellipse5Icon2 } from './Ellipse5Icon2';
import { Ellipse5Icon3 } from './Ellipse5Icon3';
import { EvaFacebookOutlineIcon } from './EvaFacebookOutlineIcon';
import { Group43Icon } from './Group43Icon';
import classes from './Hideva.module.css';
import { MingcuteTwitterLineIcon } from './MingcuteTwitterLineIcon';

interface Props {
  className?: string;
}
/* @figmaId 103:2 */
export const Hideva: FC<Props> = memo(function Hideva(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${classes.root}`}>
      <div className={classes.frame8}></div>
      <div className={classes.hIDEVA}>
        <div className={classes.rectangle4}></div>
        <div className={classes.rectangle5}></div>
        <div className={classes.home}>Home</div>
        <div className={classes.about}>About</div>
        <div className={classes.services}>Services</div>
        <div className={classes.blog}>Blog</div>
        <div className={classes.frame1}>
          <div className={classes.contactUs}>Contact us</div>
        </div>
        <div className={classes.hIDEVAGROUP}>HIDEVA GROUP </div>
        <div className={classes.frame2}>
          <div className={classes.getAQuote}>Get a quote</div>
        </div>
        <div className={classes.designAndBuildContractor}>Design and Build Contractor</div>
        <div className={classes.withUnwaveringCommitmentAndExp}>
          With unwavering commitment and expertise, we create spaces that stand as a testament to our dedication and
          craftsmanship
        </div>
        <div className={classes.weAreHidevaGroup}>We are Hideva Group</div>
        <div className={classes._18}>18+</div>
        <div className={classes.constructionServices}>Construction Services</div>
        <div className={classes._10}>10+</div>
        <div className={classes.fundiEngineers}>Fundi Engineers</div>
        <div className={classes._5}>5+</div>
        <div className={classes.regularSuppliers}>Regular Suppliers</div>
        <div className={classes.rectangle6}></div>
        <div className={classes.rectangle19}></div>
        <div className={classes.aboutUs}>About us</div>
        <div className={classes.efficiencyBuildingBudgetTime}>Efficiency, Building, Budget &amp; Time</div>
        <div className={classes.hidevaGroupIsATeamOfSkilledCon}>
          Hideva Group is a team of skilled construction professionals with a passion for building and a commitment to
          excellence. We provide a range of services, from small-scale renovations to large-scale commercial
          construction. We believe in transparency and communication, and we work closely with our clients to ensure
          their needs are met. Thank you for considering us for your construction needs.
        </div>
        <div className={classes.rectangle7}></div>
        <div className={classes.services2}>Services</div>
        <div className={classes.buildingDreamsCraftingRealitie}>Building Dreams, Crafting Realities</div>
        <div className={classes.rectangle16}></div>
        <div className={classes.costAnalysis}>Cost analysis</div>
        <div className={classes.ellipse2}>
          <Ellipse2Icon className={classes.icon} />
        </div>
        <div className={classes.ellipse3}>
          <Ellipse3Icon className={classes.icon2} />
        </div>
        <div className={classes.permitsProcesses}>Permits &amp; Processes</div>
        <div className={classes.ellipse4}>
          <Ellipse4Icon className={classes.icon3} />
        </div>
        <div className={classes.scheduling}>Scheduling</div>
        <div className={classes.ellipse42}>
          <Ellipse4Icon2 className={classes.icon4} />
        </div>
        <div className={classes.phasing}>Phasing</div>
        <div className={classes.ellipse5}>
          <Ellipse5Icon className={classes.icon5} />
        </div>
        <div className={classes.resourceManagement}>Resource management</div>
        <div className={classes.designBuild}>Design &amp; Build</div>
        <div className={classes.ellipse1}>
          <Ellipse1Icon className={classes.icon6} />
        </div>
        <div className={classes.consultationServices}>Consultation Services</div>
        <div className={classes.rectangle39}></div>
        <div className={classes.rectangle162}></div>
        <div className={classes.rectangle40}></div>
        <div className={classes.rectangle17}></div>
        <div className={classes.rectangle41}></div>
        <div className={classes.maintenanceServices}>Maintenance Services</div>
        <div className={classes.sidingRepairs}>Siding Repairs</div>
        <div className={classes.ellipse22}>
          <Ellipse2Icon2 className={classes.icon7} />
        </div>
        <div className={classes.ellipse32}>
          <Ellipse3Icon2 className={classes.icon8} />
        </div>
        <div className={classes.plumbing}>Plumbing</div>
        <div className={classes.ellipse43}>
          <Ellipse4Icon3 className={classes.icon9} />
        </div>
        <div className={classes.electricalSolarFitting}>Electrical &amp;Solar Fitting</div>
        <div className={classes.ellipse44}>
          <Ellipse4Icon4 className={classes.icon10} />
        </div>
        <div className={classes.hVAC}>HVAC</div>
        <div className={classes.ellipse52}>
          <Ellipse5Icon2 className={classes.icon11} />
        </div>
        <div className={classes.remodeling}>Remodeling</div>
        <div className={classes.windowsDoorsFitting}>Windows &amp; Doors Fitting</div>
        <div className={classes.ellipse12}>
          <Ellipse1Icon2 className={classes.icon12} />
        </div>
        <div className={classes.generalConstruction}>General Construction</div>
        <div className={classes.buildingAddition}>Building Addition</div>
        <div className={classes.ellipse23}>
          <Ellipse2Icon3 className={classes.icon13} />
        </div>
        <div className={classes.ellipse33}>
          <Ellipse3Icon3 className={classes.icon14} />
        </div>
        <div className={classes.renovation}>Renovation</div>
        <div className={classes.ellipse45}>
          <Ellipse4Icon5 className={classes.icon15} />
        </div>
        <div className={classes.restoration}>Restoration</div>
        <div className={classes.ellipse46}>
          <Ellipse4Icon6 className={classes.icon16} />
        </div>
        <div className={classes.rebuildingFromDrainage}>Rebuilding from Drainage</div>
        <div className={classes.ellipse53}>
          <Ellipse5Icon3 className={classes.icon17} />
        </div>
        <div className={classes.drainage}>Drainage</div>
        <div className={classes.newConstruction}>New Construction</div>
        <div className={classes.ellipse13}>
          <Ellipse1Icon3 className={classes.icon18} />
        </div>
        <div className={classes.insightfulBlogsAboutTheConstru}>Insightful blogs about the construction industry.</div>
        <div className={classes.blog2}>Blog</div>
        <div className={classes.rectangle21}></div>
        <div className={classes.whatAreTheProcessesInvolvedInP}>
          What are the processes involved in putting up a building?
        </div>
        <div className={classes._24October2022}>24 October 2022</div>
        <div className={classes.theProcessOfPuttingUpABuilding}>
          The process of putting up a building is usually done in phases and understanding this phases is important to a
          client in terms...
        </div>
        <div className={classes.frame3}>
          <div className={classes.readMore}>Read more</div>
        </div>
        <div className={classes.rectangle28}></div>
        <div className={classes.whatIsMinimalistArchitectureAn}>
          What is Minimalist Architecture and Minimal Design Space?
        </div>
        <div className={classes._3November2022}>3 November 2022</div>
        <div className={classes.minimalismInArchitectureIsAFor}>
          Minimalism in architecture is a form that can be characterized using various aspects with the sole aim of
          reducing clutter and...
        </div>
        <div className={classes.frame4}>
          <div className={classes.readMore2}>Read more</div>
        </div>
        <div className={classes.rectangle29}></div>
        <div className={classes.integratingTechnologyForModern}>Integrating Technology for Modern Construction</div>
        <div className={classes._5January2023}>5 January 2023</div>
        <div className={classes.inTheRealmOfModernConstruction}>
          In the realm of modern construction, the integration of smart home innovations has emerged as a transformative
          force...
        </div>
        <div className={classes.frame5}>
          <div className={classes.readMore3}>Read more</div>
        </div>
        <div className={classes.getInTouch}>Get in Touch</div>
        <div className={classes.reachOutToUsAndLetSTurnYourCon}>
          Reach out to us and let&#39;s turn your construction dreams into reality
        </div>
        <div className={classes.rectangle30}></div>
        <div className={classes.frame6}>
          <div className={classes.send}>Send</div>
        </div>
        <div className={classes.name}>Name</div>
        <div className={classes.rectangle31}></div>
        <div className={classes.johnDoe}>John Doe</div>
        <div className={classes.email}>Email</div>
        <div className={classes.rectangle33}></div>
        <div className={classes.johndoeGmailCom}>johndoe@gmail.com</div>
        <div className={classes.rectangle34}></div>
        <div className={classes.message}>Message</div>
        <div className={classes.rectangle35}></div>
        <div className={classes.hIDEVAGROUP2}>HIDEVA GROUP </div>
        <div className={classes.services3}>Services</div>
        <div className={classes.newBuilds}>New Builds</div>
        <div className={classes.renovations}>Renovations</div>
        <div className={classes.conversions}>Conversions</div>
        <div className={classes.fitOut}>Fit Out</div>
        <div className={classes.information}>Information</div>
        <div className={classes.events}>Events</div>
        <div className={classes.contactUs2}>Contact us</div>
        <div className={classes.privacyPolicy}>Privacy policy</div>
        <div className={classes.termsOfServices}>Terms of services</div>
        <div className={classes.address}>Address</div>
        <div className={classes.nyeriTownNyeri}>Nyeri Town - Nyeri</div>
        <div className={classes.mumbi}>Mumbi</div>
        <div className={classes.callUs}>Call us</div>
        <div className={classes.line1}></div>
        <div className={classes.line2}></div>
        <div className={classes.emailUs}>Email us</div>
        <div className={classes.group43}>
          <Group43Icon className={classes.icon19} />
        </div>
        <div className={classes.rectangle38}></div>
        <div className={classes.mingcuteTwitterLine}>
          <MingcuteTwitterLineIcon className={classes.icon20} />
        </div>
        <div className={classes.rectangle37}></div>
        <div className={classes.evaFacebookOutline}>
          <EvaFacebookOutlineIcon className={classes.icon21} />
        </div>
      </div>
    </div>
  );
});
